const DB_NAME = "barberStyleDB";
const DB_VERSION = 2;

export const STORES = {
    USUARIOS: "usuarios",
    TURNOS: "turnos",
};

export function abrirBaseDatos() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
            const db = event.target.result;

            // Tabla de usuarios
            if (!db.objectStoreNames.contains(STORES.USUARIOS)) {
                const usuarios = db.createObjectStore(STORES.USUARIOS, {
                    keyPath: "id",
                    autoIncrement: true,
                });

                usuarios.createIndex("usuario", "usuario", {
                    unique: true,
                });
            }

            // Tabla de turnos
            if (!db.objectStoreNames.contains(STORES.TURNOS)) {
                const turnos = db.createObjectStore(STORES.TURNOS, {
                    keyPath: "id",
                    autoIncrement: true,
                });

                turnos.createIndex("fecha", "fecha");
                turnos.createIndex("estado", "estado");
            }


            if (!db.objectStoreNames.contains("sesion")) {
                db.createObjectStore("sesion", {
                    keyPath: "id",
                });
            }

        };

        request.onsuccess = () => {
            resolve(request.result);
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}