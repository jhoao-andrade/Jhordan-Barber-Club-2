import { abrirBaseDatos, STORES } from "./database";

export async function crearTurno(turno) {
    const db = await abrirBaseDatos();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            STORES.TURNOS,
            "readwrite"
        );

        const store = transaction.objectStore(STORES.TURNOS);

        const request = store.add({
            ...turno,
            estado: "Pendiente",
        });

        request.onsuccess = () => {
            resolve(request.result);
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}

export async function obtenerTurnos() {
    const db = await abrirBaseDatos();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            STORES.TURNOS,
            "readonly"
        );

        const store = transaction.objectStore(STORES.TURNOS);

        const request = store.getAll();

        request.onsuccess = () => {
            resolve(request.result);
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}

export async function buscarTurnoPorFechaHora(
    fecha,
    hora
) {
    const turnos = await obtenerTurnos();

    return turnos.find(
        (turno) =>
            turno.fecha === fecha &&
            turno.hora === hora &&
            turno.estado !== "Cancelado"
    );
}

export async function aceptarTurno(id) {
    const db = await abrirBaseDatos();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            STORES.TURNOS,
            "readwrite"
        );

        const store = transaction.objectStore(STORES.TURNOS);

        const request = store.get(id);

        request.onsuccess = () => {
            const turno = request.result;

            if (!turno) {
                reject(
                    new Error("Turno no encontrado")
                );
                return;
            }

            turno.estado = "Aceptado";

            const updateRequest = store.put(turno);

            updateRequest.onsuccess = () => {
                resolve(turno);
            };

            updateRequest.onerror = () => {
                reject(updateRequest.error);
            };
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}

export async function eliminarTurno(id) {
    const db = await abrirBaseDatos();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            STORES.TURNOS,
            "readwrite"
        );

        const store = transaction.objectStore(STORES.TURNOS);

        const request = store.delete(id);

        request.onsuccess = () => {
            resolve(true);
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}