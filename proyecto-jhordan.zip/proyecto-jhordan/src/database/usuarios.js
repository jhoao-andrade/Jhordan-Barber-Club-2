import { abrirBaseDatos, STORES } from "./database";

export async function crearUsuario(usuario) {
    const usuarioExistente =
        await buscarUsuarioPorNombre(
            usuario.usuario
        );

    if (usuarioExistente) {
        throw new Error(
            "Ese nombre de usuario está en uso."
        );
    }

    const db = await abrirBaseDatos();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            STORES.USUARIOS,
            "readwrite"
        );

        const store =
            transaction.objectStore(
                STORES.USUARIOS
            );

        const request = store.add({
            ...usuario,
            usuario: usuario.usuario.trim(),
        });

        request.onsuccess = () => {
            resolve(request.result);
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}

export async function obtenerUsuarios() {
    const db = await abrirBaseDatos();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            STORES.USUARIOS,
            "readonly"
        );

        const store = transaction.objectStore(STORES.USUARIOS);

        const request = store.getAll();

        request.onsuccess = () => {
            resolve(request.result);
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}

export async function buscarUsuario(usuario, contrasena) {
    const usuarios = await obtenerUsuarios();

    const usuarioNormalizado = usuario.trim().toLowerCase();
    const contrasenaNormalizada = contrasena.trim();

    return usuarios.find(
        (item) =>
            item.usuario.trim().toLowerCase() ===
            usuarioNormalizado &&
            item.contrasena === contrasenaNormalizada
    );
}

export async function buscarUsuarioPorNombre(usuario) {
    const usuarios = await obtenerUsuarios();

    const usuarioNormalizado =
        usuario.trim().toLowerCase();

    return usuarios.find(
        (item) =>
            item.usuario.trim().toLowerCase() ===
            usuarioNormalizado
    );
}

/* =================================
   CREAR ADMINISTRADOR POR DEFECTO
================================= */

export async function crearAdministrador() {
    const administrador = await buscarUsuarioPorNombre(
        "barbero"
    );

    if (administrador) {
        return administrador;
    }

    const id = await crearUsuario({
        nombre: "Barbero",
        usuario: "barbero",
        contrasena: "1234",
        rol: "admin",
    });

    console.log(
        "✅ Usuario administrador creado"
    );

    return {
        id,
        nombre: "Barbero",
        usuario: "barbero",
        contrasena: "1234",
        rol: "admin",
    };
}


export async function guardarSesion(usuario) {
    const db = await abrirBaseDatos();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            "sesion",
            "readwrite"
        );

        const store = transaction.objectStore("sesion");

        const request = store.put({
            id: 1,
            usuario,
        });

        request.onsuccess = () => {
            resolve(true);
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}

export async function obtenerSesion() {
    const db = await abrirBaseDatos();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            "sesion",
            "readonly"
        );

        const store = transaction.objectStore("sesion");

        const request = store.get(1);

        request.onsuccess = () => {
            resolve(request.result?.usuario || null);
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}

export async function cerrarSesionGuardada() {
    const db = await abrirBaseDatos();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(
            "sesion",
            "readwrite"
        );

        const store = transaction.objectStore("sesion");

        const request = store.delete(1);

        request.onsuccess = () => {
            resolve(true);
        };

        request.onerror = () => {
            reject(request.error);
        };
    });
}


export async function crearBarbero({
    nombre,
    usuario,
    contrasena,
}) {
    const usuarioExistente =
        await buscarUsuarioPorNombre(usuario);

    if (usuarioExistente) {
        throw new Error(
            "Ese nombre de usuario está en uso."
        );
    }

    return crearUsuario({
        nombre: nombre.trim(),
        usuario: usuario.trim(),
        contrasena,
        rol: "barbero",
    });
}