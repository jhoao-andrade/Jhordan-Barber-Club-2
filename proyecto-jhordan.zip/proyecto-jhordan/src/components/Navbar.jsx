import "../styles/Navbar.css";

function Navbar({
    paginaActual,
    cambiarPagina,
    usuarioActivo,
    cerrarSesion,
}) {
    return (
        <nav className="navbar">
            <div className="navbar-logo">
                <span className="navbar-icono">✂</span>
                <span>Jhordan Barber Club</span>
            </div>

            <div className="navbar-menu">
                <button
                    className={
                        paginaActual === "inicio"
                            ? "activo"
                            : ""
                    }
                    onClick={() =>
                        cambiarPagina("inicio")
                    }
                >
                    Inicio
                </button>

                <button
                    className={
                        paginaActual === "admin"
                            ? "activo"
                            : ""
                    }
                    onClick={() =>
                        cambiarPagina("admin")
                    }
                >
                    Admin
                </button>

                <button
                    className={
                        paginaActual === "contacto"
                            ? "activo"
                            : ""
                    }
                    onClick={() =>
                        cambiarPagina("contacto")
                    }
                >
                    Contacto
                </button>

                {usuarioActivo ? (
                    <>
                        <span className="navbar-usuario">
                            👤 {usuarioActivo.nombre}
                        </span>

                        <button
                            className="navbar-salir"
                            onClick={cerrarSesion}
                        >
                            Salir
                        </button>
                    </>
                ) : null}
            </div>
        </nav>
    );
}

export default Navbar;