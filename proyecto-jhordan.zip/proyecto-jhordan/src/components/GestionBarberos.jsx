import { useState } from "react";

import {
    crearBarbero,
} from "../database/usuarios";

function GestionBarberos() {
    const [formulario, setFormulario] = useState({
        nombre: "",
        usuario: "",
        contrasena: "",
    });

    const [mensaje, setMensaje] = useState("");

    function manejarCambio(e) {
        const { name, value } = e.target;

        setFormulario((anterior) => ({
            ...anterior,
            [name]: value,
        }));

        setMensaje("");
    }

    async function crearNuevoBarbero(e) {
        e.preventDefault();

        if (
            !formulario.nombre ||
            !formulario.usuario ||
            !formulario.contrasena
        ) {
            setMensaje(
                "Completa todos los campos."
            );
            return;
        }

        try {
            await crearBarbero(formulario);

            setMensaje(
                "✅ Barbero creado correctamente."
            );

            setFormulario({
                nombre: "",
                usuario: "",
                contrasena: "",
            });
        } catch (error) {
            console.error(error);

            setMensaje(
                "❌ Ese nombre de usuario está en uso."
            );
        }
    }

    return (
        <section className="gestion-barberos">
            <div className="gestion-barberos-header">
                <div>
                    <h2>Gestión de barberos</h2>

                    <p>
                        Crea nuevas cuentas para los barberos
                        de BarberStyle.
                    </p>
                </div>

                <span>💈</span>
            </div>

            <form
                className="barbero-form"
                onSubmit={crearNuevoBarbero}
            >
                <div className="barbero-campo">
                    <label>Nombre completo</label>

                    <input
                        type="text"
                        name="nombre"
                        placeholder="Nombre del barbero"
                        value={formulario.nombre}
                        onChange={manejarCambio}
                    />
                </div>

                <div className="barbero-campo">
                    <label>Usuario</label>

                    <input
                        type="text"
                        name="usuario"
                        placeholder="Usuario para iniciar sesión"
                        value={formulario.usuario}
                        onChange={manejarCambio}
                    />
                </div>

                <div className="barbero-campo">
                    <label>Contraseña</label>

                    <input
                        type="password"
                        name="contrasena"
                        placeholder="Contraseña"
                        value={formulario.contrasena}
                        onChange={manejarCambio}
                    />
                </div>

                <button
                    type="submit"
                    className="btn-crear-barbero"
                >
                    + Crear barbero
                </button>
            </form>

            {mensaje && (
                <p className="barbero-mensaje">
                    {mensaje}
                </p>
            )}
        </section>
    );
}

export default GestionBarberos;