import { useEffect, useState } from "react";

import {
    crearTurno,
    buscarTurnoPorFechaHora,
    obtenerTurnos,
} from "../database/turnos";

import "../styles/Inicio.css";

function CitaForm() {
    const [formulario, setFormulario] = useState({
        nombre: "",
        servicio: "",
        fecha: "",
        hora: "",
    });

    const [mensaje, setMensaje] = useState("");
    const [horasOcupadas, setHorasOcupadas] = useState([]);

    const horasDisponibles = [
        "09:00",
        "10:00",
        "11:00",
        "12:00",
        "13:00",
        "14:00",
        "15:00",
        "16:00",
        "17:00",
        "18:00",
        "19:00",
    ];

    useEffect(() => {
        async function cargarHorasOcupadas() {
            if (!formulario.fecha) {
                setHorasOcupadas([]);
                return;
            }

            try {
                const turnos = await obtenerTurnos();

                const ocupadas = turnos
                    .filter(
                        (turno) =>
                            turno.fecha === formulario.fecha &&
                            turno.estado !== "Cancelado"
                    )
                    .map((turno) => turno.hora);

                setHorasOcupadas(ocupadas);

                if (ocupadas.includes(formulario.hora)) {
                    setFormulario((anterior) => ({
                        ...anterior,
                        hora: "",
                    }));
                }
            } catch (error) {
                console.error(error);
            }
        }

        cargarHorasOcupadas();
    }, [formulario.fecha]);

    function manejarCambio(e) {
        const { name, value } = e.target;

        setFormulario((anterior) => ({
            ...anterior,
            [name]: value,
        }));

        setMensaje("");
    }

    async function enviarCita(e) {
        e.preventDefault();

        if (
            !formulario.nombre ||
            !formulario.servicio ||
            !formulario.fecha ||
            !formulario.hora
        ) {
            setMensaje(
                "Por favor completa todos los campos."
            );
            return;
        }

        try {
            const turnoExistente =
                await buscarTurnoPorFechaHora(
                    formulario.fecha,
                    formulario.hora
                );

            if (turnoExistente) {
                setMensaje(
                    "❌ Ese horario ya está reservado. Elige otra hora."
                );

                return;
            }

            await crearTurno(formulario);

            setMensaje(
                "✅ ¡Cita registrada correctamente!"
            );

            setFormulario({
                nombre: "",
                servicio: "",
                fecha: "",
                hora: "",
            });

            setHorasOcupadas([]);
        } catch (error) {
            console.error(error);

            setMensaje(
                "❌ No se pudo guardar la cita."
            );
        }
    }

    function restablecer() {
        setFormulario({
            nombre: "",
            servicio: "",
            fecha: "",
            hora: "",
        });

        setMensaje("");
        setHorasOcupadas([]);
    }

    return (
        <section className="cita-card">
            <div className="cita-titulo">
                <span>📅</span>
                <h2>Reserva tu cita</h2>
            </div>

            <form onSubmit={enviarCita}>
                <div className="campo">
                    <label>Nombre</label>

                    <input
                        type="text"
                        name="nombre"
                        placeholder="Tu nombre"
                        value={formulario.nombre}
                        onChange={manejarCambio}
                    />
                </div>

                <div className="campo">
                    <label>Servicio</label>

                    <select
                        name="servicio"
                        value={formulario.servicio}
                        onChange={manejarCambio}
                    >
                        <option value="">
                            Selecciona un servicio
                        </option>

                        <option value="Corte clásico">
                            Corte clásico 25.000
                        </option>

                        <option value="Corte + barba">
                            Corte + barba 30.000
                        </option>

                        <option value="Barba">
                            Barba 15.000
                        </option>

                        <option value="Corte infantil">
                            Corte infantil 20.000
                        </option>
                    </select>
                </div>

                <div className="fila-campos">
                    <div className="campo">
                        <label>Fecha</label>

                        <input
                            type="date"
                            name="fecha"
                            value={formulario.fecha}
                            onChange={manejarCambio}
                        />
                    </div>

                    <div className="campo">
                        <label>Hora</label>

                        <select
                            name="hora"
                            value={formulario.hora}
                            onChange={manejarCambio}
                            disabled={!formulario.fecha}
                        >
                            <option value="">
                                {formulario.fecha
                                    ? "Selecciona una hora"
                                    : "Primero selecciona una fecha"}
                            </option>

                            {horasDisponibles.map((hora) => {
                                const ocupada =
                                    horasOcupadas.includes(hora);

                                return (
                                    <option
                                        key={hora}
                                        value={hora}
                                        disabled={ocupada}
                                    >
                                        {hora}
                                        {ocupada
                                            ? " - Ocupada"
                                            : " - Disponible"}
                                    </option>
                                );
                            })}
                        </select>
                    </div>
                </div>

                {formulario.fecha && (
                    <p className="horarios-info">
                        🟢 Disponible &nbsp; | &nbsp;
                        🔴 Ocupada
                    </p>
                )}

                <div className="cita-botones">
                    <button
                        type="button"
                        className="btn-restablecer"
                        onClick={restablecer}
                    >
                        Restablecer
                    </button>

                    <button
                        type="submit"
                        className="btn-cita"
                    >
                        Enviar cita
                    </button>
                </div>

                {mensaje && (
                    <p className="mensaje-cita">
                        {mensaje}
                    </p>
                )}
            </form>
        </section>
    );
}

export default CitaForm;