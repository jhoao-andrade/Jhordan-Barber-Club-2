import { useEffect, useState } from "react";

import {
    obtenerTurnos,
    aceptarTurno,
    eliminarTurno,
} from "../database/turnos";

import GestionBarberos from "./GestionBarberos";

import "../styles/Admin.css";

function Admin({ usuario, cerrarSesion }) {
    const [turnos, setTurnos] = useState([]);
    const [cargando, setCargando] = useState(true);
    const [mensaje, setMensaje] = useState("");

    async function cargarTurnos() {
        try {
            setCargando(true);

            const datos = await obtenerTurnos();

            // Ordenar por fecha y hora
            datos.sort((a, b) => {
                const fechaA = `${a.fecha} ${a.hora}`;
                const fechaB = `${b.fecha} ${b.hora}`;

                return fechaA.localeCompare(fechaB);
            });

            setTurnos(datos);
        } catch (error) {
            console.error(error);

            setMensaje(
                "❌ No se pudieron cargar las citas."
            );
        } finally {
            setCargando(false);
        }
    }

    useEffect(() => {
        cargarTurnos();
    }, []);

    async function aceptar(id) {
        try {
            await aceptarTurno(id);

            setMensaje(
                "✅ Cita aceptada correctamente."
            );

            await cargarTurnos();
        } catch (error) {
            console.error(error);

            setMensaje(
                "❌ No se pudo aceptar la cita."
            );
        }
    }

    async function eliminar(id) {
        const confirmar = window.confirm(
            "¿Seguro que quieres eliminar esta cita?"
        );

        if (!confirmar) {
            return;
        }

        try {
            await eliminarTurno(id);

            setMensaje(
                "🗑️ Cita eliminada correctamente."
            );

            await cargarTurnos();
        } catch (error) {
            console.error(error);

            setMensaje(
                "❌ No se pudo eliminar la cita."
            );
        }
    }

    const pendientes = turnos.filter(
        (turno) => turno.estado === "Pendiente"
    );

    const aceptadas = turnos.filter(
        (turno) => turno.estado === "Aceptado"
    );

    return (
        <main className="admin-panel">

            <div className="admin-contenedor">

                {/* ENCABEZADO */}

                <header className="admin-header">

                    <div>
                        <span className="admin-icono">
                            ✂
                        </span>

                        <h1>
                            {usuario?.rol === "admin"
                                ? "Panel de administración"
                                : "Panel del barbero"}
                        </h1>

                        <p>
                            Bienvenido,{" "}
                            <strong>
                                {usuario?.nombre || "Usuario"}
                            </strong>
                        </p>


                        <span className="admin-rol">
                            {usuario?.rol === "admin"
                                ? "👑 Administrador"
                                : "💈 Barbero"}
                        </span>
                    </div>

                    <button
                        className="admin-logout"
                        onClick={cerrarSesion}
                    >
                        Cerrar sesión
                    </button>

                </header>
                {usuario?.rol === "admin" && (
                    <GestionBarberos />
                )}
                {/* ESTADÍSTICAS */}

                <section className="admin-estadisticas">

                    <div className="estadistica">
                        <span>📋</span>

                        <div>
                            <strong>
                                {turnos.length}
                            </strong>

                            <p>Total de citas</p>
                        </div>
                    </div>

                    <div className="estadistica">
                        <span>🟡</span>

                        <div>
                            <strong>
                                {pendientes.length}
                            </strong>

                            <p>Pendientes</p>
                        </div>
                    </div>

                    <div className="estadistica">
                        <span>🟢</span>

                        <div>
                            <strong>
                                {aceptadas.length}
                            </strong>

                            <p>Aceptadas</p>
                        </div>
                    </div>

                </section>

                {/* MENSAJE */}

                {mensaje && (
                    <div className="admin-mensaje">
                        {mensaje}
                    </div>
                )}

                {/* TÍTULO */}

                <div className="admin-titulo">

                    <div>
                        <h2>Reservas</h2>

                        <p>
                            Citas almacenadas en la base de datos
                        </p>
                    </div>

                    <button
                        className="btn-recargar"
                        onClick={cargarTurnos}
                    >
                        🔄 Actualizar
                    </button>

                </div>

                {/* CONTENIDO */}

                {cargando ? (
                    <div className="admin-vacio">
                        <p>
                            Cargando citas...
                        </p>
                    </div>
                ) : turnos.length === 0 ? (
                    <div className="admin-vacio">
                        <span>📅</span>

                        <h3>
                            No hay citas todavía
                        </h3>

                        <p>
                            Las nuevas reservas aparecerán aquí.
                        </p>
                    </div>
                ) : (
                    <section className="turnos-lista">

                        {turnos.map((turno) => (
                            <article
                                key={turno.id}
                                className="turno-card"
                            >

                                <div className="turno-info">

                                    <div className="turno-cliente">
                                        <span>👤</span>

                                        <div>
                                            <h3>
                                                {turno.nombre}
                                            </h3>

                                            <p>
                                                Cliente
                                            </p>
                                        </div>
                                    </div>

                                    <div className="turno-datos">

                                        <div>
                                            <span>💈</span>

                                            <p>
                                                <strong>
                                                    Servicio
                                                </strong>

                                                <br />

                                                {turno.servicio}
                                            </p>
                                        </div>

                                        <div>
                                            <span>📅</span>

                                            <p>
                                                <strong>
                                                    Fecha
                                                </strong>

                                                <br />

                                                {turno.fecha}
                                            </p>
                                        </div>

                                        <div>
                                            <span>🕐</span>

                                            <p>
                                                <strong>
                                                    Hora
                                                </strong>

                                                <br />

                                                {turno.hora}
                                            </p>
                                        </div>

                                    </div>

                                </div>

                                <div className="turno-acciones">

                                    <span
                                        className={
                                            turno.estado === "Aceptado"
                                                ? "estado aceptado"
                                                : "estado pendiente"
                                        }
                                    >
                                        {turno.estado === "Aceptado"
                                            ? "🟢 Aceptado"
                                            : "🟡 Pendiente"}
                                    </span>

                                    {turno.estado === "Pendiente" && (
                                        <button
                                            className="btn-aceptar"
                                            onClick={() =>
                                                aceptar(turno.id)
                                            }
                                        >
                                            ✓ Aceptar
                                        </button>
                                    )}

                                    <button
                                        className="btn-eliminar"
                                        onClick={() =>
                                            eliminar(turno.id)
                                        }
                                    >
                                        🗑️
                                    </button>

                                </div>

                            </article>
                        ))}

                    </section>
                )}

            </div>

        </main>
    );
}

export default Admin;