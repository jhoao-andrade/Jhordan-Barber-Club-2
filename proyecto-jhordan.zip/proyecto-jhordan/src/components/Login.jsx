import { useState } from "react";
import { buscarUsuario } from "../database/usuarios";
import "../styles/Login.css";

function Login({ iniciarSesion, irARegistro, volverInicio }) {
    const [usuario, setUsuario] = useState("");
    const [contrasena, setContrasena] = useState("");
    const [mensaje, setMensaje] = useState("");

    async function manejarLogin(e) {
        e.preventDefault();

        if (!usuario || !contrasena) {
            setMensaje("Completa todos los campos.");
            return;
        }

        try {
            const usuarioEncontrado = await buscarUsuario(
                usuario,
                contrasena
            );

            if (!usuarioEncontrado) {
                setMensaje("❌ Usuario o contraseña incorrectos.");
                return;
            }

            setMensaje("");

            iniciarSesion(usuarioEncontrado);
        } catch (error) {
            console.error(error);

            setMensaje(
                "❌ Ocurrió un error al iniciar sesión."
            );
        }
    }

    return (
        <main className="login-panel">
            <div className="login-card">

                <div className="login-icon">
                    ✂
                </div>

                <h1>Jhordan Barber Club</h1>

                <h2>Iniciar sesión</h2>

                <form onSubmit={manejarLogin}>

                    <div className="login-campo">
                        <label>Usuario</label>

                        <input
                            type="text"
                            placeholder="Ingresa tu usuario"
                            value={usuario}
                            onChange={(e) =>
                                setUsuario(e.target.value)
                            }
                        />
                    </div>

                    <div className="login-campo">
                        <label>Contraseña</label>

                        <input
                            type="password"
                            placeholder="Ingresa tu contraseña"
                            value={contrasena}
                            onChange={(e) =>
                                setContrasena(e.target.value)
                            }
                        />
                    </div>

                    {mensaje && (
                        <p className="login-mensaje">
                            {mensaje}
                        </p>
                    )}

                    <button
                        type="submit"
                        className="btn-login"
                    >
                        Iniciar sesión
                    </button>
                </form>

                <div className="login-registro">
                    <p>
                        ¿No tienes una cuenta?
                    </p>

                    <button
                        onClick={irARegistro}
                        className="btn-registrarse"
                    >
                        Crear cuenta
                    </button>
                </div>

                <button
                    onClick={volverInicio}
                    className="btn-volver"
                >
                    ← Volver al inicio
                </button>

            </div>
        </main>
    );
}

export default Login;