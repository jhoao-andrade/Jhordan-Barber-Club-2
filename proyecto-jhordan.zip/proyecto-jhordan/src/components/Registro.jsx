import { useState } from "react";

import {
    crearUsuario,
    buscarUsuarioPorNombre,
} from "../database/usuarios";

import "../styles/Registro.css";

function Registro({ volverLogin }) {
    const [formulario, setFormulario] = useState({
        nombre: "",
        usuario: "",
        contrasena: "",
        confirmarContrasena: "",
        rol: "cliente",
    });

    const [mensaje, setMensaje] = useState("");

    function manejarCambio(e) {
        const { name, value } = e.target;

        setFormulario((anterior) => ({
            ...anterior,
            [name]: value,
        }));

        setMensaje("");
    }

    async function registrarse(e) {
        e.preventDefault();

        const {
            nombre,
            usuario,
            contrasena,
            confirmarContrasena,
        } = formulario;

        if (
            !nombre ||
            !usuario ||
            !contrasena ||
            !confirmarContrasena
        ) {
            setMensaje(
                "Completa todos los campos."
            );
            return;
        }

        if (contrasena !== confirmarContrasena) {
            setMensaje(
                "Las contraseñas no coinciden."
            );
            return;
        }

        try {
            const usuarioExistente =
                await buscarUsuarioPorNombre(usuario);

            if (usuarioExistente) {
                setMensaje(
                    "❌ Ese nombre de usuario ya existe y esta en uso."
                );
                return;
            }

            await crearUsuario({
                nombre,
                usuario,
                contrasena,
                rol: "cliente",
            });

            setMensaje(
                "✅ Cuenta creada correctamente."
            );

            setFormulario({
                nombre: "",
                usuario: "",
                contrasena: "",
                confirmarContrasena: "",
                rol: "cliente",
            });

            setTimeout(() => {
                volverLogin();
            }, 1200);
        } catch (error) {
            console.error(error);

            setMensaje(
                "❌ No se pudo crear la cuenta."
            );
        }
    }

    return (
        <main className="registro-panel">
            <div className="registro-card">
                <div className="registro-icon">
                    👤
                </div>

                <h1>Crear cuenta</h1>

                <p className="registro-subtitulo">
                    Regístrate en Jhordan Barber Club y disfruta de nuestros servicios.
                </p>

                <form onSubmit={registrarse}>
                    <div className="registro-campo">
                        <label>Nombre completo</label>

                        <input
                            type="text"
                            name="nombre"
                            placeholder="Tu nombre"
                            value={formulario.nombre}
                            onChange={manejarCambio}
                        />
                    </div>

                    <div className="registro-campo">
                        <label>Usuario</label>

                        <input
                            type="text"
                            name="usuario"
                            placeholder="Crea un usuario"
                            value={formulario.usuario}
                            onChange={manejarCambio}
                        />
                    </div>

                    

                    <div className="registro-campo">
                        <label>Contraseña</label>

                        <input
                            type="password"
                            name="contrasena"
                            placeholder="Crea una contraseña"
                            value={formulario.contrasena}
                            onChange={manejarCambio}
                        />
                    </div>

                    <div className="registro-campo">
                        <label>Confirmar contraseña</label>

                        <input
                            type="password"
                            name="confirmarContrasena"
                            placeholder="Repite la contraseña"
                            value={formulario.confirmarContrasena}
                            onChange={manejarCambio}
                        />
                    </div>

                    {mensaje && (
                        <p className="registro-mensaje">
                            {mensaje}
                        </p>
                    )}

                    <button
                        type="submit"
                        className="btn-registro"
                    >
                        Crear cuenta
                    </button>
                </form>

                <button
                    onClick={volverLogin}
                    className="btn-volver-registro"
                >
                    ← Volver al login
                </button>
            </div>
        </main>
    );
}

export default Registro;