import { useEffect, useState } from "react";

import Navbar from "./components/Navbar";
import Inicio from "./pages/Inicio";
import Contacto from "./pages/Contacto";
import Login from "./components/Login";
import Registro from "./components/Registro";
import Admin from "./components/Admin";

import {
  abrirBaseDatos,
} from "./database/database";

import {
  crearAdministrador,
  guardarSesion,
  obtenerSesion,
  cerrarSesionGuardada,
} from "./database/usuarios";

function App() {
  const [paginaActual, setPaginaActual] =
    useState("inicio");

  const [usuarioActivo, setUsuarioActivo] =
    useState(null);

  const [modoLogin, setModoLogin] =
    useState(false);

  const [modoRegistro, setModoRegistro] =
    useState(false);

  const [cargando, setCargando] =
    useState(true);

  useEffect(() => {
    async function iniciarAplicacion() {
      try {
        await abrirBaseDatos();

        await crearAdministrador();

        const sesion =
          await obtenerSesion();

        if (sesion) {
          setUsuarioActivo(sesion);

          if (sesion.rol === "admin") {
            setPaginaActual("admin");
          } else {
            setPaginaActual("inicio");
          }
        }
      } catch (error) {
        console.error(
          "❌ Error al iniciar la aplicación:",
          error
        );
      } finally {
        setCargando(false);
      }
    }

    iniciarAplicacion();
  }, []);

  async function iniciarSesion(usuario) {
    try {
      await guardarSesion(usuario);

      setUsuarioActivo(usuario);

      setModoLogin(false);
      setModoRegistro(false);

      if (usuario.rol === "admin") {
        setPaginaActual("admin");
      } else {
        setPaginaActual("inicio");
      }
    } catch (error) {
      console.error(error);
    }
  }

  async function cerrarSesion() {
    try {
      await cerrarSesionGuardada();

      setUsuarioActivo(null);
      setModoLogin(false);
      setModoRegistro(false);
      setPaginaActual("inicio");
    } catch (error) {
      console.error(error);
    }
  }

  function mostrarPagina() {
    if (modoRegistro) {
      return (
        <Registro
          volverLogin={() => {
            setModoRegistro(false);
            setModoLogin(true);
          }}
        />
      );
    }

    if (modoLogin) {
      return (
        <Login
          iniciarSesion={iniciarSesion}
          irARegistro={() => {
            setModoLogin(false);
            setModoRegistro(true);
          }}
          volverInicio={() => {
            setModoLogin(false);
            setPaginaActual("inicio");
          }}
        />
      );
    }

    if (
      paginaActual === "admin" &&
      (
        usuarioActivo?.rol === "admin" ||
        usuarioActivo?.rol === "barbero"
      )
    ) {
      return (
        <Admin
          usuario={usuarioActivo}
          cerrarSesion={cerrarSesion}
        />
      );
    }

    if (paginaActual === "contacto") {
      return <Contacto />;
    }

    return <Inicio />;
  }

  function cambiarPagina(pagina) {
    if (pagina === "admin") {
      if (
        usuarioActivo?.rol === "admin" ||
        usuarioActivo?.rol === "barbero"
      ) {
        setPaginaActual("admin");
        return;
      }

      setModoLogin(true);
      return;
    }

    setPaginaActual(pagina);
  }

  if (cargando) {
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#111",
          color: "white",
          fontSize: "18px",
        }}
      >
        Cargando BarberStyle...
      </div>
    );
  }

  return (
    <div className="app">
      {!modoLogin && !modoRegistro && (
        <Navbar
          paginaActual={paginaActual}
          cambiarPagina={cambiarPagina}
          usuarioActivo={usuarioActivo}
          cerrarSesion={cerrarSesion}
        />
      )}

      {mostrarPagina()}
    </div>
  );
}

export default App;