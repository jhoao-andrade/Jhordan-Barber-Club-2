import CitaForm from "../components/CitaForm";
import "../styles/Inicio.css";

function Inicio() {
    return (
        <main className="inicio">
            <div className="inicio-fondo"></div>

            <div className="inicio-contenido">
                <section className="inicio-presentacion">
                    <span className="inicio-icono">✂</span>

                    <h1>Jhordan Barber Club</h1>

                    <h2>Tu estilo, nuestra pasión</h2>

                    <p>
                        Reserva tu cita de forma rápida y sencilla.
                        Elige tu servicio, selecciona la fecha y la hora
                        que prefieras.
                    </p>
                </section>
                
                <CitaForm />

                <div className="footer-pagina">
                    <p>&copy; 2026 Jhordan Barber Club. Todos los derechos reservados.</p>
                </div>
            </div>
        </main>
    );
}

export default Inicio;