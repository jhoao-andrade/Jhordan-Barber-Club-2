import "../styles/Contacto.css";

function Contacto() {
    return (
        <main className="contacto-panel">
            <div className="contacto-contenedor">
                <div className="contacto-encabezado">
                    <span className="contacto-icono">✂</span>

                    <h1>Contacto</h1>

                    <p>
                        ¿Tienes alguna pregunta? Estamos aquí para ayudarte.
                    </p>
                </div>

                <section className="contacto-grid">
                    <div className="contacto-card">
                        <span>📍</span>
                        <h2>Ubicación</h2>
                        <p>
                            Visítanos en nuestra barbería.
                        </p>
                        <strong>
                            Calle Principal # 19 34-20 - QUIBDO CHOCO - CARAÑO BONANZA
                        </strong>
                    </div>

                    <div className="contacto-card">
                        <span>📞</span>
                        <h2>Teléfono</h2>
                        <p>
                            Llámanos para resolver tus dudas.
                        </p>
                        <strong>
                            +57 3113750584
                        </strong>
                    </div>

                    <div className="contacto-card">
                        <span>✉️</span>
                        <h2>Correo</h2>
                        <p>
                            Escríbenos cuando quieras.
                        </p>
                        <strong>
                            contacto@jhordanbarberclub.com
                        </strong>
                    </div>

                    <div className="contacto-card">
                        <span>🕐</span>
                        <h2>Horario</h2>
                        <p>
                            Lunes a sábado
                        </p>
                        <strong>
                            9:00 AM - 7:00 PM
                        </strong>
                    </div>
                </section>
                
            </div>

            <div className="footer-pagina">
                <p>&copy; 2026 Jhordan Barber Club. Todos los derechos reservados.</p>
            </div>
        </main>
    );
}

export default Contacto;